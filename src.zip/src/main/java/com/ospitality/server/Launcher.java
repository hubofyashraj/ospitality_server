package com.ospitality.server;

import java.io.IOException;

public class Launcher {
    public static void main(String[] args) throws IOException {
        Main.main(args);
    }
}
